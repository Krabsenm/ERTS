#include "start.h"

void start::Execute(EmbeddedSystemX* context, EmbeddedSystemState* state)
{
	state->Start(context);
}
