#include "selfTestOk.h"

void selfTestOk::Execute(EmbeddedSystemX* context, EmbeddedSystemState* state)
{
	state->SelftestOk(context);
}
